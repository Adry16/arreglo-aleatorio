/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arreglo_aleatorio.main;

import arreglo_aleatorio.frames.frmArreglo;

/**
 *
 * @author Ivan
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        frmArreglo a = new frmArreglo();
        a.setVisible(true);
        a.setLocationRelativeTo(null);
    }
    
}
